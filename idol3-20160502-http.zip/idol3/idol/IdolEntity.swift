//
//  IdolEntity.swift
//  idol
//
//  Created by 吴汪洋 on 15/12/15.
//  Copyright © 2015年 吴汪洋. All rights reserved.
//

import Foundation
import CoreData


class IdolEntity: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
